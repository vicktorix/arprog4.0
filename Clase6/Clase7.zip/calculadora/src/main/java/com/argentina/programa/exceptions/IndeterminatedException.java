package com.argentina.programa.exceptions;

public class IndeterminatedException extends Exception {

    public IndeterminatedException() {
        super("Indeterminated result exception");
    
    }
    
}
