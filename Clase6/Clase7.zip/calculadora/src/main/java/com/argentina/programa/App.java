package com.argentina.programa;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        new MenuCalculadora().ejecutar();
    }
}
