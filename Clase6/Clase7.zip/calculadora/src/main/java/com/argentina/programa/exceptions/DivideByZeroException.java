package com.argentina.programa.exceptions;

public class DivideByZeroException extends Exception {

    public DivideByZeroException() {
        super("Divide by zero Exception");
    }
    
}
