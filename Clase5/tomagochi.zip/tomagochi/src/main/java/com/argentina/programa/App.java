package com.argentina.programa;

import com.argentina.programa.tomagochi.Tomagochi;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        new Tomagochi().ejecutar();
    }
}
